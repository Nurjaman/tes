
<table align="center">
    <tr>
        <th>Menu</th>
    </tr>
    <tr>
        <td>
            <select name="pilihan">
                <option value="XML">XML</option>
                <option value="XML">JSON</option>
            </select>
        </td>
    </tr>
    <tr>
        <td><input type="submit" value="kirim" class="pure-button pure-button-primary" </td>
    </tr>


</table>