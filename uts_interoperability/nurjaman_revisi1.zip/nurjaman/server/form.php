<!DOCTYPE html>
<head>
    <title>Form inputan</title>
</head>
<body>
<form action="#" method="POST">
    <table border="0"">
        <tr>
            <th>NIK </th>
            <th>:</th>
            <td><input type="text" name="nik" id="nik"></input></td>
        </tr>

        <tr>
            <th>Nama </th>
            <th>:</th>
            <td><input type="text" name="nama" id="nama" </td>
        </tr>

        <tr>
            <th>Jenis Kelamin </th>
            <th>:</th>
            <td>
                <select name=jenis_kelamin" id="jenis_kelamin">
                    <option value="L">Laki - Laki</option>
                    <option value="P">Perempuan</option>
                </select>
            </td>
        </tr>

        <tr>
            <th>Jabatan</th>
            <th>:</th>
            <td>
                <select name="jabatan" id="jabatan">
                    <option value="MG">Manager</option>
                    <option value="KY">Karyawan</option>
                    <option value="OB">Opisboy</option>
                </select>
            </td>
        </tr>

        <tr>
            <td colspan="3">
                <input type="button" name="Kirim" id="kirim" value="Kirim">
            </td>
        </tr>
    </table>

</form>

</body>

